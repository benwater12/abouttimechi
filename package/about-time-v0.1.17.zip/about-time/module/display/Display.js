import { ElapsedTime } from "../ElapsedTime.js";
import { DateTime } from "../calendar/DateTime.js";
import { DTMod } from "../calendar/DTMod.js";
import { PseudoClock } from "../PseudoClock.js";
let displayMain = null;
export class SimpleCalendarDisplay extends FormApplication {
    constructor(object = {}, options = null) {
        super(object, options);
    }
    static showClock() {
        if (!displayMain)
            displayMain = new SimpleCalendarDisplay();
        displayMain.render(true);
    }
    static updateClock() {
        if (displayMain) {
            displayMain.render(false);
        }
    }
    activateListeners(html) {
        super.activateListeners(html);
        if (!PseudoClock.isMaster())
            return;
        $(html)
            .find("#about-time-calendar-btn-min")
            .click(event => {
            // @ts-ignore
            let now = game.Gametime.DTNow();
            let timeSpec = { hours: now.hours, minutes: now.minutes + 1, seconds: 0 };
            ElapsedTime.setTime(timeSpec);
            this.render(false);
        });
        $(html)
            .find("#about-time-calendar-btn-tenMin")
            .click(event => {
            // @ts-ignore
            let now = game.Gametime.DTNow();
            let timeSpec = { hours: now.hours, minutes: now.minutes + 10, seconds: 0 };
            ElapsedTime.setTime(timeSpec);
            this.render(false);
        });
        $(html)
            .find("#about-time-calendar-btn-long")
            .click(event => {
            ElapsedTime.advanceTime({ hours: 1 });
            this.render(false);
        });
        $(html)
            .find("#about-time-calendar-btn-day")
            .click(event => {
            let newDT = DateTime.now().add(new DTMod({ days: 1 })).setAbsolute({ hours: 7, minutes: 0, seconds: 0 });
            ElapsedTime.setAbsolute(newDT);
            this.render(false);
        });
        $(html)
            .find("#about-time-calendar-btn-night")
            .click(event => {
            let newDT = DateTime.now().add(new DTMod({ days: 1 })).setAbsolute({ hours: 0, minutes: 0, seconds: 0 });
            ElapsedTime.setAbsolute(newDT);
            this.render(false);
        });
        $(html)
            .find("#about-time-calendar-time")
            .click(event => {
            if (PseudoClock.isRunning())
                PseudoClock.stopRealTime();
            else
                PseudoClock.startRealTime();
            this.render(false);
        });
    }
    get title() {
        let now = DateTime.now().shortDate();
        return now.date + " " + now.time;
    }
    static get defaultOptions() {
        const options = super.defaultOptions;
        options.template = "modules/about-time/templates/simpleCalendarDisplay.html";
        // options.width = 520;
        // options.height = 520; // should be "auto", but foundry has problems with dynamic content
        options.title = DateTime.now().longDate().time;
        return options;
    }
    /**
     * Provides data to the form, which then can be rendered using the handlebars templating engine
     */
    getData() {
        return { now: DateTime.now().longDate(), running: (PseudoClock.isRunning() === undefined || PseudoClock.isRunning()) && !game.paused };
    }
    static setupHooks() {
        Hooks.on("pseudoclockSet", SimpleCalendarDisplay.updateClock);
        Hooks.on("renderPause", SimpleCalendarDisplay.updateClock);
        Hooks.on("updateCombat", SimpleCalendarDisplay.updateClock);
        Hooks.on("deleteCombat", SimpleCalendarDisplay.updateClock);
    }
}

export const preloadTemplates = async function () {
    const templatePaths = [
    // Add paths to "modules/about-time/templates"
    ];
    return loadTemplates(templatePaths);
};

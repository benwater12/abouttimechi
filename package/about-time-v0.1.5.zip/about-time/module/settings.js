import { ElapsedTime } from "./ElapsedTime.js";
import { DTCalc } from "./calendar/DTCalc.js";
import { calendars } from "./calendar/DTCalc.js";
import { PseudoClock } from "./PseudoClock.js";
export const registerSettings = function () {
    // Register any custom module settings here
    let modulename = "about-time";
    game.settings.register("about-time", "real-time-multiplier", {
        name: "Game Time update multiplier",
        hint: "game clock changes 'multiplier' seconds for every second of real time change",
        scope: "world",
        config: true,
        default: 1,
        type: Number,
        onChange: PseudoClock._fetchParams
    });
    game.settings.register("about-time", "real-time-interval", {
        name: "Real time interval",
        hint: "How often the game clock updates. i.e. 30 the game clock will update every 30 seconds of real time. If 0 game clock will not update with real time changes",
        scope: "world",
        config: true,
        default: 30,
        type: Number,
        onChange: PseudoClock._fetchParams
    });
    game.settings.register("about-time", "seconds-per-round", {
        name: "Game Seconds per round",
        hint: "How long each combat round lasts",
        default: 6,
        type: Number,
        scope: 'world',
        config: true,
        onChange: ElapsedTime._fetchParams
    });
    game.settings.register("about-time", "calendar", {
        name: "Active calendar",
        hint: "Choose which calendar to use in the game",
        scope: "client",
        default: "Gregorian",
        type: String,
        choices: Object.keys(calendars),
        config: true,
        onChange: DTCalc.reload
    });
    game.settings.register("about-time", "debug", {
        name: "Debug output",
        hint: "Debug output",
        default: false,
        type: Boolean,
        scope: 'client',
        config: true,
        onChange: ElapsedTime._fetchParams
    });
    game.settings.register("about-time", "store", {
        name: "Elapsed Time event queue",
        hint: "Don't touch this",
        default: {},
        type: Object,
        scope: 'client',
        config: false,
        onChange: backup => {
        }
    });
    game.settings.register("about-time", "pseudoclock", {
        name: "Elapsed Time event queue",
        hint: "Don't touch this",
        default: {},
        type: Object,
        scope: 'world',
        config: false,
        onChange: backup => {
        }
    });
};

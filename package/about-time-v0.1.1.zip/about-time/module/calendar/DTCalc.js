export const EberronCalendar = {
    // month lengths non-leap year and leapyear
    "month_len": {
        "Needfest": [7, 7],
        "Fireseek": [28, 28],
        "Readying": [28, 28],
        "Coldeven": [28, 28],
        "Growfest": [7, 7],
        "Planting": [28, 28],
        "Flocktime": [28, 28],
        "Wealsun": [28, 28],
        "Richfest": [7, 7],
        "Reaping": [28, 28],
        "Goodmonth": [28, 28],
        "Harvester": [28, 28],
        "Brewfest": [7, 7],
        "Patchwall": [28, 28],
        "Ready'reat": [28, 28],
        "Sunsebb": [28, 28]
    },
    // rule for calculating number of leap years from 0 to year
    "leap_year_rule": (year) => 0,
    // days of week
    "weekdays": ["Starday", "Sunday", "Moonday", "Godsday", "Waterday", "Earthday", "Freeday"],
    "notes": {},
    // what is the base year for the real time clock
    "clock_start_year": 0,
    "first_day": 0,
    // time constants
    "hours_per_day": 24,
    "seconds_per_minute": 60,
    "minutes_per_hour": 60,
    // does the year have a year 0? Gregorian does not.
    "has_year_0": true
};
export const GregorianCalendar = {
    "month_len": {
        "January": [31, 31],
        "February": [28, 29],
        "March": [31, 31],
        "April": [30, 30],
        "May": [31, 31],
        "June": [30, 30],
        "July": [31, 31],
        "August": [31, 31],
        "September": [30, 30],
        "October": [31, 31],
        "November": [30, 30],
        "December": [31, 31],
    },
    "leap_year_rule": (year) => Math.floor(year / 4) - Math.floor(year / 100) + Math.floor(year / 400),
    "weekdays": ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
    "clock_start_year": 1970,
    "first_day": 6,
    "notes": {},
    "hours_per_day": 24,
    "seconds_per_minute": 60,
    "minutes_per_hour": 60,
    "has_year_0": false
};
export class DTCalc {
    constructor() {
        return this;
    }
    static _createFromData(calendarSpec = GregorianCalendar) {
        let tc = new DTCalc();
        DTCalc.spm = calendarSpec.seconds_per_minute;
        DTCalc.mph = calendarSpec.minutes_per_hour;
        DTCalc.hpd = calendarSpec.hours_per_day;
        DTCalc.spd = DTCalc.hpd * DTCalc.mph * DTCalc.spm;
        DTCalc.spw = DTCalc.spd * DTCalc.dpw;
        DTCalc.sph = DTCalc.spm * DTCalc.mph;
        // @ts-ignore
        DTCalc.dpm = Object.keys(calendarSpec.month_len).map(key => calendarSpec.month_len[key]);
        DTCalc.dpy = [0, 1].map(i => this.sum(...Object.values(DTCalc.dpm).map(a => a[i])));
        DTCalc.leapYearRule = calendarSpec.leap_year_rule;
        DTCalc.spy = DTCalc.spd * DTCalc.dpy[0]; // seconds in a normal year
        DTCalc.months = Object.keys(calendarSpec.month_len);
        DTCalc.mpy = DTCalc.months.length;
        DTCalc.month_len = calendarSpec.month_len;
        DTCalc.weekDays = calendarSpec.weekdays;
        DTCalc.dpw = calendarSpec.weekdays.length;
        ;
        DTCalc.clockStartYear = calendarSpec.clock_start_year;
        DTCalc.firstDay = calendarSpec.first_day;
        DTCalc.hasYearZero = calendarSpec.has_year_0;
        return tc;
    }
    /**
     *
     * @param year how many leap years from uear 0 to year "year"
     */
    static numLeapYears(year) {
        return this.leapYearRule(year);
    }
    static padNumber(n, digits = 2) {
        return `${n}`.padStart(digits, "0");
    }
    /**
     *
     * @param year is year "year" a leap year 1 for yes, 0 for no.
     */
    static isLeapYear(year) {
        return (this.leapYearRule(year) > this.leapYearRule(year - 1)) ? 1 : 0;
    }
    /**
     *
     * @param year how days in the year "year" - know about leap years
     */
    static daysInYear(year) {
        return this.dpy[this.isLeapYear(year)];
    }
    /**
     *
     * @param months -number of months to calculate for
     * return number of seconds in the first "months" months of the year.
     * Assumes non-leap year
     */
    static monthsToSeconds(months) {
        //@ts-ignore fromRange
        if (months === 0)
            return 0;
        //@ts-ignore
        let days = Array.fromRange(months).reduce((acc, index) => acc + DTCalc.dpm[index], 0);
        // let days = [...Array(months).keys()].map(i=>this.dpm[i]).reduce((a,b) => a + b);
        return days * DTCalc.spd;
    }
    /**
     *
     * @param {ddays, hours, minutes, second} return the equivalent total number of seconds.
     */
    static timeToSeconds({ days = 0, hours = 0, minutes = 0, seconds = 0 }) {
        return days * DTCalc.spd + hours * DTCalc.sph + minutes * DTCalc.spm + seconds;
    }
}
DTCalc.log = (...args) => {
    console.log("about-time | ", ...args);
};
DTCalc.sum = (...args) => args.reduce((acc, v) => acc + v);
// Initialise
DTCalc._createFromData(GregorianCalendar);

import { DTMod } from "./calendar/DTMod.js";
import { DateTime } from "./calendar/DateTime.js";
const _moduleSocket = "module.about-time";
const _updateClock = "updateClock";
const _eventTrigger = "eventTrigger";
const _queryMaster = "queryMaster";
const _masterResponse = "masterResponse";
let _userId = "";
let _isGM = false;
let debug;
let log = (...args) => {
    console.log("about-time | ", ...args);
};
class PseudoClockMessage {
    constructor({ action, userId, newTime = 0 }, ...args) {
        this._action = action;
        this._userId = userId;
        this._newTime = newTime;
        this._args = args;
        return this;
    }
}
export class PseudoClock {
    static get currentTime() { return PseudoClock._currentTime; }
    ;
    static get clockStartYear() { return this._clockStartYear; }
    ;
    static setDebug(val) {
        debug = val;
    }
    static _initialize(currentTime = 0, realTimeMult = 0, realTimeInteval, running = false) {
        PseudoClock._currentTime = currentTime;
        PseudoClock._running = running;
        PseudoClock._realTimeMult = realTimeMult;
        PseudoClock._realTimeInteval = realTimeInteval;
        PseudoClock._save(true);
    }
    static _createFromData(data) {
        PseudoClock._currentTime = data._currentTime || 0;
        PseudoClock._running = data._running;
        PseudoClock._realTimeMult = data._realTimeMult;
        PseudoClock._realTimeInteval = data._realTimeInteval;
        PseudoClock.setClock(PseudoClock._currentTime);
    }
    static isMaster() {
        return PseudoClock._isMaster;
    }
    static warnNotMaster(operation) {
        ui.notifications.error(`${game.user.name} ${operation} - ${game.i18n.localize("about-time.notMaster")}`);
        console.warn("Non master timekeeper attempting to set date/time");
    }
    static status() {
        console.log(PseudoClock._currentTime, PseudoClock._realTimeMult, PseudoClock._running);
    }
    static _displayCurrentTime() {
        console.log(`Elapsed time ${PseudoClock._currentTime}`);
    }
    static getDHMS() {
        return DTMod.fromSeconds(this._currentTime);
    }
    static advanceClock(timeIncrement) {
        if (PseudoClock._isMaster)
            PseudoClock.setClock(PseudoClock._currentTime + timeIncrement);
        else
            PseudoClock.warnNotMaster("Advance clock");
    }
    static setClock(newTime) {
        PseudoClock._currentTime = newTime;
        if (debug)
            log(PseudoClock._currentTime);
        if (PseudoClock._isMaster) {
            let message = new PseudoClockMessage({ action: _updateClock, userId: _userId, newTime: PseudoClock._currentTime });
            PseudoClock._notifyUsers(message);
            PseudoClock._save(false);
        }
        Hooks.callAll("pseudoclockSet", newTime);
    }
    static setDateTime(dt) {
        if (PseudoClock._isMaster) {
            let seconds = dt.toSeconds() - DateTime.create().toSeconds();
            PseudoClock.setClock(seconds);
        }
        else
            PseudoClock.warnNotMaster("pseudoclock Set Date Time");
    }
    static _realTimeHandler() {
        if (debug)
            log("Real time handler fired");
        // reschedule the handleer
        PseudoClock._realTimeTimerID = setTimeout(PseudoClock._realTimeHandler, PseudoClock._realTimeInteval);
        if (!game.paused && PseudoClock._running) {
            let gameTimeAdvance = PseudoClock._realTimeMult * PseudoClock._realTimeInteval / 1000;
            PseudoClock.advanceClock(gameTimeAdvance);
        }
    }
    static stopRealTime() {
        if (PseudoClock.isMaster)
            PseudoClock._running = false;
        else
            PseudoClock.warnNotMaster("Stop realtime");
    }
    static demote() {
        PseudoClock._isMaster = false;
        clearTimeout(PseudoClock._realTimeTimerID);
    }
    /* Start the real time clock */
    static startRealTime() {
        if (PseudoClock._isMaster) {
            clearTimeout(PseudoClock._realTimeTimerID);
            PseudoClock._realTimeTimerID = setTimeout(PseudoClock._realTimeHandler, PseudoClock._realTimeInteval);
            PseudoClock._running = true;
        }
        else
            PseudoClock.warnNotMaster("Start realtime");
    }
    static isRunning() {
        if (PseudoClock._isMaster)
            return PseudoClock._running;
    }
    static _processAction(message) {
        if (message._userId === _userId)
            return;
        switch (message._action) {
            case _updateClock:
                PseudoClock.setClock(message._newTime);
                break;
            case _eventTrigger:
                Hooks.callAll(_eventTrigger, ...message._args);
                break;
            case _queryMaster:
                log("query master received");
                if (PseudoClock._isMaster) {
                    log("responding as master time keeper");
                    let message = new PseudoClockMessage({ action: _masterResponse, userId: _userId, newTime: 0 });
                    PseudoClock._notifyUsers(message);
                }
                break;
            case _masterResponse:
                if (message._userId !== _userId) {
                    log("master timekeeper responded cancelling timeout");
                    // cancel timeout
                    clearTimeout(PseudoClock._queryTimeoutId);
                }
        }
    }
    ;
    static async notifyEvent(eventName, ...args) {
        let message = new PseudoClockMessage({ action: _eventTrigger, userId: _userId, newTime: 0 }, eventName, ...args);
        Hooks.callAll(_eventTrigger, ...message._args);
        return PseudoClock._notifyUsers(message);
    }
    static async _notifyUsers(message) {
        //@ts-ignore
        await game.socket.emit(_moduleSocket, message, resp => {
        });
    }
    static _setupSocket() {
        //@ts-ignore
        game.socket.on(_moduleSocket, (data) => {
            PseudoClock._processAction(data);
        });
    }
    ;
    static _load() {
        let saveData = game.settings.get("about-time", "pseudoclock");
        if (debug)
            log("_load", saveData);
        if (!saveData) {
            log("no saved data re-initializing");
            PseudoClock._initialize(0, 0, 30, false);
        }
        else {
            log("loaded saved Data. ", saveData);
            PseudoClock._createFromData(saveData);
        }
        PseudoClock._fetchParams();
    }
    ;
    static _save(force) {
        let newSaveTime = Date.now();
        if (this._isMaster) {
            if (newSaveTime - PseudoClock._lastSaveTime > PseudoClock._saveInterval || force) {
                if (debug)
                    log("_save saving", new Date(), PseudoClock.currentTime);
                let saveData = {
                    _currentTime: PseudoClock._currentTime,
                    _running: PseudoClock._running,
                    _realTimeInteval: PseudoClock._realTimeInteval,
                    _realTimeMult: PseudoClock._realTimeMult
                };
                // put something in to throttle saving
                game.settings.set("about-time", "pseudoclock", saveData);
            }
            PseudoClock._lastSaveTime = newSaveTime;
        }
    }
    static init() {
        _userId = game.user.id;
        //@ts-ignore
        _isGM = game.user.isGM;
        PseudoClock._lastSaveTime = Date.now();
        PseudoClock._fetchParams();
        // find a better way to do this.
        PseudoClock._isMaster = false;
        PseudoClock._setupSocket();
        if (_isGM) {
            if (debug)
                log("pseudoclock sending query master message");
            // 1 send a message to see if there is another master clock already out there
            let message = new PseudoClockMessage({ action: _queryMaster, userId: _userId });
            PseudoClock._notifyUsers(message);
            let timeout = game.settings.get("about-time", "election-timeout") * 1000;
            // 2 set a timeout, if it expires assume master timekeeper role.
            PseudoClock._queryTimeoutId = setTimeout(() => {
                log("Timeout expired assuming master timekeeper role");
                PseudoClock._isMaster = true;
                PseudoClock._load();
                clearTimeout(PseudoClock._realTimeTimerID);
                PseudoClock._realTimeTimerID = setTimeout(PseudoClock._realTimeHandler, PseudoClock._realTimeInteval);
            }, timeout);
        }
        if (debug)
            log("election-timeout: timeout set id is ", PseudoClock._queryTimeoutId);
    }
    static _fetchParams() {
        PseudoClock._realTimeMult = game.settings.get("about-time", "real-time-multiplier") || 1;
        PseudoClock._realTimeInteval = (game.settings.get("about-time", "real-time-interval") || 10) * 1000;
    }
}
PseudoClock._saveInterval = 5 * 60 * 1000; // only save every 5 minutes real time. make a param.
PseudoClock._clockStartYear = 1;

export const preloadTemplates = async function () {
    const templatePaths = [
        // Add paths to "modules/about-time/templates"
        'modules/about-time/templates/simpleCalendarDisplay.html'
    ];
    return loadTemplates(templatePaths);
};
